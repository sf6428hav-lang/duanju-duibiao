import os
import sys
import json
import ssl
import base64
import subprocess
import urllib.request
import urllib.parse
import asyncio
from typing import Optional

from fastapi import FastAPI, File, UploadFile, Form, Query, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import imageio_ffmpeg
import cv2

app = FastAPI(title="Video Script Generator FastAPI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SCRATCH_DIR = os.path.dirname(os.path.abspath(__file__))
ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
ctx = ssl._create_unverified_context()

@app.get("/api/health")
async def health():
    return {"status": "ok", "message": "FastAPI local backend server is active!"}

@app.get("/api/models")
async def get_models(base_url: str = Query("https://yunwu.ai"), api_key: str = Query("")):
    clean_base_url = base_url.rstrip("/")
    try:
        req_url = f"{clean_base_url}/v1/models" if not clean_base_url.endswith("/v1") else f"{clean_base_url}/models"
        req = urllib.request.Request(req_url, headers={"Authorization": f"Bearer {api_key}"})
        res = urllib.request.urlopen(req, timeout=15, context=ctx)
        data = json.loads(res.read().decode('utf-8'))
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/upload_and_analyze")
async def upload_and_analyze(
    video: UploadFile = File(...),
    base_url: Optional[str] = Form(None),
    api_key: Optional[str] = Form(None),
    model: Optional[str] = Form(None),
    prompt: Optional[str] = Form(None),
    no_slice: Optional[str] = Form(None),
    episode_num: Optional[str] = Form(None),
    prev_characters: Optional[str] = Form(None),
    prev_context: Optional[str] = Form(None)
):
    ext = os.path.splitext(video.filename)[1] or ".mp4"
    ep_num_str = str(episode_num or "1")
    saved_path = os.path.join(SCRATCH_DIR, f"temp_upload_{ep_num_str}{ext}")
    
    contents = await video.read()
    with open(saved_path, "wb") as f:
        f.write(contents)

    clean_base_url = (base_url or "https://yunwu.ai").rstrip("/")
    clean_api_key = api_key or ""
    clean_model = model or "gemini-3.1-pro-preview"
    clean_prompt = prompt or ""
    is_no_slice = (str(no_slice or "true").lower() in ["true", "1", "yes"])
    ep_num = int(ep_num_str) if ep_num_str.isdigit() else 1
    clean_prev_chars = prev_characters or ""
    clean_prev_ctx = prev_context or ""

    return StreamingResponse(
        stream_fast_timeout_pipeline(saved_path, clean_base_url, clean_api_key, clean_model, clean_prompt, is_no_slice, ep_num, clean_prev_chars, clean_prev_ctx),
        media_type="text/event-stream"
    )

def clean_and_merge_script(script_text: str) -> str:
    import re
    if not script_text:
        return ""
    
    # 1. 彻底擦除垃圾切片占位符（如 第X集X-）
    cleaned = re.sub(r'第X集X-?', '', script_text)
    
    # 2. 擦除场头与▲的标点杂质（1-1、 -> 1-1 ； ▲. -> ▲ ）
    cleaned = re.sub(r'^(\d+-\d+)[、,，]\s*', r'\1 ', cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r'^▲[.\s、]+', r'▲ ', cleaned, flags=re.MULTILINE)
    
    # 3. 彻底擦除“难以置信”与“在一旁瞪大双眼”黑名单词汇
    cleaned = re.sub(r'难以置信地?', '', cleaned)
    cleaned = re.sub(r'，?在一旁瞪大双眼', '', cleaned)
    cleaned = re.sub(r'瞪大双眼，?', '', cleaned)
    
    # 4. 彻底解封连贯台词：绝不强行合并同角色的两条台词！按行保留并清理
    lines = [l.strip() for l in cleaned.split('\n') if l.strip()]
    processed_lines = []
    
    for l in lines:
        # 如果台词中混入了内嵌括号（例：台词？（无奈叹气）妹啊...），将其拆分为两行
        if '：' in l or ':' in l:
            # 擦除冒号后台词中间的内嵌括号（保留冒号前面的规范情绪括号）
            parts = re.split(r'([:：])', l, maxsplit=1)
            if len(parts) == 3:
                speaker_part = parts[0]
                sep = parts[1]
                dialogue_part = parts[2]
                
                # 如果台词中间带有了内嵌括号如 （无奈叹气），拆分为新的一句
                inner_bracket_match = re.search(r'(.+?)[（\(]([^）\)]+)[）\)](.+)', dialogue_part)
                if inner_bracket_match:
                    d1 = inner_bracket_match.group(1).strip()
                    inner_emo = inner_bracket_match.group(2).strip()
                    d2 = inner_bracket_match.group(3).strip()
                    
                    clean_speaker = re.sub(r'[（\(][^）\)]+[）\)]', '', speaker_part)
                    processed_lines.append(f"{speaker_part}{sep}{d1}")
                    if d2:
                        processed_lines.append(f"{clean_speaker}（{inner_emo}）：{d2}")
                    continue
                else:
                    processed_lines.append(l)
                    continue
        processed_lines.append(l)
        
    return '\n\n'.join(processed_lines)

async def stream_fast_timeout_pipeline(file_path: str, base_url: str, api_key: str, model: str, prompt: str, no_slice: bool = True, episode_num: int = 1, prev_characters: str = "", prev_context: str = ""):
    def send_evt(data_dict):
        return f"data: {json.dumps(data_dict, ensure_ascii=False)}\n\n"

    clean_filename = os.path.splitext(os.path.basename(file_path))[0]
    yield send_evt({'type': 'progress', 'msg': f'1/4 正在利用 FFmpeg 提取第 {episode_num} 集视频的无损音轨与视频帧...'})
    await asyncio.sleep(0.1)

    audio_path = os.path.join(SCRATCH_DIR, 'temp_full_audio.mp3')
    cmd_audio = f'"{ffmpeg_exe}" -y -i "{file_path}" -vn -acodec libmp3lame -q:a 0 "{audio_path}"'
    subprocess.run(cmd_audio, capture_output=True, encoding='utf-8', errors='ignore', shell=True)

    cap = cv2.VideoCapture(file_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration_sec = total_frames / fps if fps else 60.0

    if no_slice:
        chunk_sec = duration_sec
        num_chunks = 1
        yield send_evt({'type': 'progress', 'msg': f'2/4 音画提取完成！全剧 {duration_sec:.1f} 秒，采用【全量直接生成】模式 (不切割切片)...'})
    else:
        chunk_sec = 25.0
        num_chunks = max(1, int(duration_sec // chunk_sec) + (1 if duration_sec % chunk_sec > 3 else 0))
        yield send_evt({'type': 'progress', 'msg': f'2/4 音画提取完成！全剧 {duration_sec:.1f} 秒，拆分为 {num_chunks} 个 AI 分析单元...'})

    await asyncio.sleep(0.1)

    full_script = ""
    last_context_summary = "无（00:00秒开篇第一句）"
    last_scene_no = "1-1"
    global_characters = ""

    for c in range(num_chunks):
        if no_slice:
            start_t = 0.0
            end_t = duration_sec
            frame_count_target = max(1, int(duration_sec))
            yield send_evt({'type': 'progress', 'msg': f'3/4 全量视频发起 AI 解析 (全剧 {duration_sec:.1f}s，严格每秒 1 帧高密抽帧共 {frame_count_target} 帧)...'})
            chunk_audio_path = audio_path
        else:
            start_t = c * chunk_sec
            end_t = min((c + 1) * chunk_sec, duration_sec)
            if start_t >= duration_sec: break
            yield send_evt({'type': 'progress', 'msg': f'3/4 正在拆解第 {c+1}/{num_chunks} 单元 ({start_t:.1f}s ~ {end_t:.1f}s)，正在发起 API 请求...'})
            chunk_audio_path = os.path.join(SCRATCH_DIR, f'temp_audio_{c+1}.mp3')
            cmd_slice = f'"{ffmpeg_exe}" -y -ss {start_t} -to {end_t} -i "{audio_path}" -acodec copy "{chunk_audio_path}"'
            subprocess.run(cmd_slice, capture_output=True, encoding='utf-8', errors='ignore', shell=True)

        await asyncio.sleep(0.1)

        audio_b64 = ""
        if os.path.exists(chunk_audio_path):
            with open(chunk_audio_path, 'rb') as f:
                audio_b64 = base64.b64encode(f.read()).decode('utf-8')

        if no_slice:
            frame_count_target = max(1, int(duration_sec))
            step = 1.0
            new_w = 480
            quality = 45 if frame_count_target > 80 else 55
        else:
            frame_count_target = 25
            step = max(0.4, (end_t - start_t) / frame_count_target)
            new_w = 640
            quality = 85

        chunk_frames = []
        for k in range(frame_count_target):
            sec = start_t + (k * step)
            if sec >= duration_sec: sec = max(0, duration_sec - 0.1)
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(sec * fps))
            ret, frame = cap.read()
            if ret:
                h, w = frame.shape[:2]
                new_h = int(h * (new_w / w))
                resized = cv2.resize(frame, (new_w, new_h))
                _, buf = cv2.imencode('.jpg', resized, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
                b64_img = base64.b64encode(buf).decode('utf-8')
                m = int(sec // 60)
                s = int(sec % 60)
                chunk_frames.append((f"{m:02d}:{s:02d}", f"data:image/jpeg;base64,{b64_img}"))

        char_inherit_prompt = ""
        if prev_characters:
            char_inherit_prompt = f"""
【全局角色姓名锁死继承（强制）】：
- 前几集已确定的男女主与主要人物姓名表为：【{prev_characters}】。
- 本集为第 {episode_num} 集，必须 100% 沿用【{prev_characters}】姓名！**绝对禁止中途更换男女主名字**！**绝对禁止退化使用‘女主/男主’等模糊代称**！
"""
        context_inherit_prompt = ""
        if prev_context:
            context_inherit_prompt = f"""
【前情剧本剧情与台词衔接】：
- 上一集结尾情节点为：“{prev_context}”。
- 本集为第 {episode_num} 集，请承接上述情节点继续书写。
"""

        if no_slice:
            breakdown_prompt = f"""{prompt}

========================================
【最高硬性规则·第 {episode_num} 集视频解析 (每秒 1 帧高密采样)】
短剧剧名/文件名：《{clean_filename}》。
全剧总时长：{duration_sec:.1f}秒（0.0s 至 {duration_sec:.1f}s）。
集数序号：【第 {episode_num} 集】
{char_inherit_prompt}
{context_inherit_prompt}

【核心强制规则】：
1. **集数标头声明**：正文必须从“第{episode_num}集”开始书写输出！
2. **原声台词与字幕 100% 逐字听写（核心）**：
   - 请逐字逐句听写视频中的每一句台词，绝对禁止做任何概括、合并或省略！
3. **画面动作 1:1 帧级还原**：
   - 结合每秒 1 帧的高密采样画面，精确描写每一个神态、眼神与动作！
========================================
"""
        else:
            if c == 0:
                seamless_rule = f"1. **开篇 00:00.0 第一句台词零遗漏**：必须从开场第一字、第一句台词、从‘第{episode_num}集’标头开始输出正文！"
                if prev_characters:
                    char_rule = f"2. **全局角色姓名锁死继承（强制）**：前几集已确定的男女主姓名表为：【{prev_characters}】。本集（第{episode_num}集）必须 100% 继承沿用【{prev_characters}】姓名，严禁变动名字！"
                else:
                    char_rule = "2. **全局人名首发定义（核心）**：请认真辨认识别视频中出现的人物真实姓名（如‘顾明礼’、‘顾明珠’），在‘人物：...’行中列出！"
            else:
                seamless_rule = f"""1. **无缝自然平滑衔接上文（绝对核心）**：
   - 上一单元结尾最后一句描写为：“{last_context_summary}”。
   - 本单元必须紧接上一句“{last_context_summary}”往后继续书写正文，绝对禁止发生动作与台词断层！
   - **绝对禁止重新输出‘第{episode_num}集’**！
   - **绝对禁止重新输出‘1-1、...’或‘人物：...’标头**（除非发生了真实的大换场）！直接写动作与台词！"""
                if global_characters:
                    char_rule = f"""2. **全局人名绝对固定锁死（核心）**：
   - 全剧已锁定人物姓名表：【{global_characters}】。
   - 本单元必须 100% 沿用【{global_characters}】姓名！**绝对禁止中途换名**！
   - **绝对禁止退化使用‘女主/男主’等模糊代称**！"""
                elif prev_characters:
                    char_rule = f"""2. **全局人名绝对固定锁死（核心）**：
   - 本集继承前集人物姓名表：【{prev_characters}】。
   - 本单元必须沿用前文确定的名字！绝对禁止中途换名！"""
                else:
                    char_rule = """2. **全局人名绝对固定锁死（核心）**：
   - 本单元必须沿用前文确定的名字！绝对禁止中途换名，绝对禁止使用‘女主/男主’等代称！"""

            breakdown_prompt = f"""{prompt}

========================================
【最高硬性规则·第 {episode_num} 集·第 {c+1}/{num_chunks} 单元】
短剧剧名/文件名：《{clean_filename}》。
当前时间轴：{start_t:.1f}s 至 {end_t:.1f}s。
前情接续状态：上一单元停留在场次【{last_scene_no}】，结尾描述：“{last_context_summary}”。

【核心强制规则】：
{seamless_rule}
{char_rule}
3. **原声台词与字幕 100% 逐字听写（核心）**：
   - 请认真听清无损音轨里的每一句对话、看清画面底部的印制字幕！
   - 原视频说的每一句台词，必须 100% 独立成行写出，绝对禁止概括、合并或省略任何一句台词！
========================================
"""

        user_contents = [
            {'type': 'text', 'text': f'【短剧《{clean_filename}》{start_t:.1f}s ~ {end_t:.1f}s 切片画面与无损音轨】：请 1:1 零删减输出全量台词与动作：'}
        ]
        if audio_b64:
            user_contents.append({'type': 'image_url', 'image_url': {'url': f'data:audio/mp3;base64,{audio_b64}'}})

        for ts, img_url in chunk_frames:
            user_contents.append({'type': 'text', 'text': f'【时间戳 {ts}】'})
            user_contents.append({'type': 'image_url', 'image_url': {'url': img_url}})

        payload = {
            'model': model,
            'messages': [
                {'role': 'system', 'content': breakdown_prompt},
                {'role': 'user', 'content': user_contents}
            ],
            'temperature': 0.1,
            'max_tokens': 16384
        }

        stage1_raw_text = ""
        chat_url = f"{base_url}/v1/chat/completions" if not base_url.endswith("/v1") else f"{base_url}/chat/completions"

        # -------------------------------------------------------------
        # 📍 阶段一：1:1 客观全量音画与台词提取
        # -------------------------------------------------------------
        for attempt in range(2):
            try:
                req = urllib.request.Request(chat_url, data=json.dumps(payload).encode('utf-8'), headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                })
                res = urllib.request.urlopen(req, timeout=60, context=ctx)
                data = json.loads(res.read().decode('utf-8'))

                if 'error' in data:
                    raise Exception(data['error'].get('message', 'API Error'))

                content = data['choices'][0]['message']['content']
                if content and content.strip():
                    stage1_raw_text = content.strip()
                    break
                else:
                    raise Exception("模型返回空内容")
            except urllib.error.HTTPError as he:
                try:
                    err_body = he.read().decode('utf-8', errors='ignore')
                    err_json = json.loads(err_body)
                    msg = err_json.get('error', {}).get('message', he.reason)
                except Exception:
                    msg = he.reason

                if he.code == 403:
                    err_msg = f"HTTP 403 拒绝访问: API Key 额度不足或已受限。(报错: {msg})"
                elif he.code == 503:
                    err_msg = f"HTTP 503 服务不可用: 当前模型 ({model}) 暂不可用。(报错: {msg})"
                else:
                    err_msg = f"HTTP {he.code}: {msg}"
                yield send_evt({'type': 'error', 'message': err_msg})
                cap.release()
                return
            except Exception as ex:
                if attempt == 1:
                    yield send_evt({'type': 'error', 'message': f"连接 API 阶段一提取失败: {str(ex)}"})
                    cap.release()
                    return
                yield send_evt({'type': 'progress', 'msg': f'⚠️ 第 {c+1} 单元 API 阶段一提取重试 ({attempt+1}/2)...'})

        if not stage1_raw_text:
            yield send_evt({'type': 'error', 'message': f'第 {c+1} 单元 阶段一未提取到内容'})
            cap.release()
            return

        # -------------------------------------------------------------
        # 📍 阶段二：对照视频画面的多模态专业编剧精修重组 (Solution A Multimodal)
        # -------------------------------------------------------------
        yield send_evt({'type': 'progress', 'msg': f'3/4 阶段一提取完成！正在启动阶段二【对照视频画面的多模态专业编剧精修重组】...'})
        await asyncio.sleep(0.1)

        stage2_system_prompt = f"""你是一位现场经验极其丰富的高级短剧主编与剧本总监。在【步骤二】中，你天然扮演【质检精修大厨】。步骤一的初始草稿可能在细节上粗心混淆，但【步骤二】你必须全量质检，发现以下违规病症并 100% 强制修正改过来！

{prompt}

========================================
【🚨 步骤二强制检测与修正的核心四大病症（必改！）】
========================================

一、 💥 病症一检测与修正：同角色的多句问句/台词被硬缝在一行（必拆成两行！）
1. **检测**：扫描草稿中是否有同一个角色把两句话或两个问句死板硬粘在同一行（例：❌ `顾明礼（...）：给我的是宫斗爬龙床？ 妹啊，咱俩的系统是不是绑反了？`）。
2. **修正**：你必须强制将其拆分为两行独立的台词！第二句赋予独立的现场神态/情绪括号（例：
   ✅ `顾明礼（指着自己，咬牙切齿）：给我的是宫斗爬龙床？`
   `顾明珠（点头）：嗯。`
   `顾明礼（崩溃）：妹啊，咱俩的系统是不是绑反了？`）。

二、 🎬 病症二检测与修正：画面 ▲ 被硬拆成碎片段落（必合并为一条连贯镜头！）
1. **检测**：扫描草稿中是否有紧接着发生的相近动作被拆成了两条零碎的 ▲（例：❌ `▲ 顾明珠闻言低头查看双手。` 紧接着 ❌ `▲ 顾明珠面前浮现出一块蓝色全息面板...`）。
2. **修正**：你必须强制将这两条连贯动作与现场视觉画面**合并写入同一条 ▲ 中**（例：
   ✅ `▲ 顾明珠闻言低头查看双手，一道蓝色的系统面板悬浮在她面前。`）。

三、 🚨 病症三检测与修正：台词文本中间内嵌二次括号（必擦除！）
1. **检测**：扫描草稿台词文本中间是否有 `（无奈叹气）` 等二次内嵌括号。
2. **修正**：括号只能且必须放在冒号前面！台词中间的二次括号必须擦除或拆分成新的一行！

四、 🧹 病症四检测与修正：格式杂质与切片垃圾字符（必擦除！）
1. **擦除**：句尾掉落的 `第X集X-` 占位符必须 100% 擦除！
2. **标准化**：场头统一为 `1-1 日/内 房间`（擦除 `1-1、` 顿号）；画面统一为 `▲ 画面描写`（擦除 `▲.` 句点）。

========================================
【三、 通用基础质检铁律（保持 1:1 精准对齐）】
========================================
1. **动作就近跟随台词**：大动作留在 ▲，说话时的伴随动作（如 `指着自己`）必须就近放入那句台词的括号中。
2. **系统 VO 禁加动作**：系统 VO 属于无实体电子音，括号内只写声音状态（如 `系统 VO（机械音）：`）。
3. **脑补字卡擦除**：除画面肉眼可见的官方剧情字卡外，凭空脑补的角色身份牌整行擦除！
4. **保留声音语气词**：自然允许使用 `破音大喊`、`咬牙切齿`、`叹气`、`哽咽`、`憋笑` 等真实配音神态。

========================================
【⚠️ 最终输出前的强制静默自查指令（必须自动检核）】
========================================
在输出最终剧本前，你必须在后台静默检核以上规则，如有违规必须立刻自我擦除修正后才能输出！
直接输出经过【步骤二视频对照审稿与标杆剧本精修】后的最终专业剧本正文！
"""

        stage2_user_contents = [
            {'type': 'text', 'text': f'===【阶段一原始草稿】===\n{stage1_raw_text}\n======================\n\n请对照下方真实视频画面与音轨，对以上草稿进行专业编剧精修重组，直接输出最终剧本正文：'}
        ]
        if audio_b64:
            stage2_user_contents.append({'type': 'image_url', 'image_url': {'url': f'data:audio/mp3;base64,{audio_b64}'}})

        for ts, img_url in chunk_frames:
            stage2_user_contents.append({'type': 'text', 'text': f'【时间戳 {ts}】'})
            stage2_user_contents.append({'type': 'image_url', 'image_url': {'url': img_url}})

        stage2_payload = {
            'model': model,
            'messages': [
                {'role': 'system', 'content': stage2_system_prompt},
                {'role': 'user', 'content': stage2_user_contents}
            ],
            'temperature': 0.0,
            'max_tokens': 16384
        }

        chunk_script = ""
        for attempt in range(2):
            try:
                req = urllib.request.Request(chat_url, data=json.dumps(stage2_payload).encode('utf-8'), headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                })
                res = urllib.request.urlopen(req, timeout=60, context=ctx)
                data = json.loads(res.read().decode('utf-8'))

                if 'error' in data:
                    raise Exception(data['error'].get('message', 'API Error'))

                content = data['choices'][0]['message']['content']
                if content and content.strip():
                    chunk_script = content.strip()
                    break
                else:
                    chunk_script = stage1_raw_text
            except Exception as ex:
                if attempt == 1:
                    chunk_script = stage1_raw_text
                    break

        if chunk_script:
            lines = [l.strip() for l in chunk_script.split('\n') if l.strip()]
            if lines:
                last_context_summary = lines[-1][:80]
            scene_matches = [l for l in lines if ('1-' in l or '场' in l)]
            if scene_matches:
                last_scene_no = scene_matches[-1][:15]

            # 解析第一单元中定义的角色名字列表
            if c == 0:
                import re
                char_match = re.search(r'人物[：:]\s*(.+)', chunk_script)
                if char_match:
                    global_characters = char_match.group(1).strip()

            cleaned_chunk = clean_and_merge_script(chunk_script.strip())
            if full_script and c > 0:
                chunk_lines = cleaned_chunk.split('\n')
                filtered_lines = []
                for line in chunk_lines:
                    sline = line.strip()
                    if sline == "第1集" or sline.startswith("1-1") or sline.startswith("人物：") or sline.startswith("人物:"):
                        continue
                    filtered_lines.append(line)
                cleaned_chunk = "\n".join(filtered_lines).strip()
                full_script += "\n" + cleaned_chunk
            else:
                full_script = cleaned_chunk

            yield send_evt({'type': 'chunk', 'content': cleaned_chunk, 'chunk_index': c + 1, 'total_chunks': num_chunks})
        else:
            yield send_evt({'type': 'error', 'message': f'第 {c+1} 单元 API 未返回内容，请检查 Base URL 与 Key'})
            cap.release()
            return

    cap.release()

    if not full_script or not full_script.strip():
        yield send_evt({'type': 'error', 'message': 'API 接口未返回内容。'})
        return

    desktop_dir = os.path.join(os.path.expanduser('~'), 'Desktop')
    if not os.path.exists(desktop_dir):
        desktop_dir = SCRATCH_DIR
    desktop_txt = os.path.join(desktop_dir, f"{clean_filename}_1对1零删减全量剧本.txt")
    with open(desktop_txt, 'w', encoding='utf-8') as f:
        f.write(full_script)

        full_script = clean_and_merge_script(full_script)
        yield send_evt({'type': 'done', 'full_script': full_script, 'desktop_file': desktop_txt})


app.mount("/", StaticFiles(directory=SCRATCH_DIR, html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=False)
