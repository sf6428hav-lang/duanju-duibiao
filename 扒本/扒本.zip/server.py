import os
import sys
import json
import ssl
import re
import glob
import base64
import subprocess
import urllib.request
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
import imageio_ffmpeg
import cv2

PORT = 8080
SCRATCH_DIR = os.path.dirname(os.path.abspath(__file__))
ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
ctx = ssl._create_unverified_context()

class NativeVideoHandler(BaseHTTPRequestHandler):
    def _set_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With')
        self.send_header('Access-Control-Allow-Private-Network', 'true')

    def do_OPTIONS(self):
        self.send_response(200)
        self._set_cors_headers()
        self.end_headers()

    def do_GET(self):
        try:
            self._handle_get()
        except Exception as e:
            print(f"[GET Error]: {e}", flush=True)

    def _handle_get(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == '/api/health':
            body_bytes = json.dumps({'status': 'ok', 'message': 'Python local backend server is running!'}).encode('utf-8')
            self.send_response(200)
            self._set_cors_headers()
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body_bytes)))
            self.end_headers()
            self.wfile.write(body_bytes)
            return

        if path == '/api/models':
            base_url = query.get('base_url', ['https://yunwu.ai'])[0].rstrip('/')
            api_key = query.get('api_key', [''])[0]
            
            try:
                req_url = f"{base_url}/v1/models" if not base_url.endswith("/v1") else f"{base_url}/models"
                req = urllib.request.Request(req_url, headers={'Authorization': f'Bearer {api_key}'})
                res = urllib.request.urlopen(req, timeout=15, context=ctx)
                data = res.read()
                
                self.send_response(200)
                self._set_cors_headers()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                err_bytes = json.dumps({'error': str(e)}).encode('utf-8')
                self.send_response(500)
                self._set_cors_headers()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(err_bytes)))
                self.end_headers()
                self.wfile.write(err_bytes)
            return

        # Serve static file
        if path == '/' or path == '/index.html':
            filepath = os.path.join(SCRATCH_DIR, 'index.html')
        else:
            filepath = os.path.join(SCRATCH_DIR, path.lstrip('/'))

        if os.path.exists(filepath) and os.path.isfile(filepath):
            with open(filepath, 'rb') as f:
                content = f.read()
            self.send_response(200)
            self._set_cors_headers()
            if filepath.endswith('.html'):
                self.send_header('Content-Type', 'text/html; charset=utf-8')
            elif filepath.endswith('.js'):
                self.send_header('Content-Type', 'application/javascript; charset=utf-8')
            elif filepath.endswith('.css'):
                self.send_header('Content-Type', 'text/css; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        else:
            self.send_error(404, "File not found")

    def parse_multipart(self, body, boundary):
        parts = body.split(boundary)
        fields = {}
        files = {}
        for part in parts:
            if not part or part == b'--\r\n' or part == b'--':
                continue
            if b'\r\n\r\n' in part:
                headers_part, content = part.split(b'\r\n\r\n', 1)
                if content.endswith(b'\r\n'):
                    content = content[:-2]
                headers_text = headers_part.decode('utf-8', errors='replace')
                name_match = re.search(r'name="([^"]+)"', headers_text)
                filename_match = re.search(r'filename="([^"]+)"', headers_text)
                
                if name_match:
                    field_name = name_match.group(1)
                    if filename_match:
                        files[field_name] = {
                            'filename': filename_match.group(1),
                            'content': content
                        }
                    else:
                        fields[field_name] = content.decode('utf-8', errors='replace')
        return fields, files

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path in ['/api/upload_and_analyze', '/api/analyze_native_stream', '/api/analyze']:
            content_type = self.headers.get('Content-Type', '')
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)

            file_path = None
            base_url = 'https://yunwu.ai'
            api_key = ''
            model = 'gemini-3.1-pro-preview'
            prompt = ''

            no_slice = True

            episode_num = 1
            prev_characters = ""
            prev_context = ""

            if 'multipart/form-data' in content_type:
                boundary_match = re.search(r'boundary=(.+)', content_type)
                if boundary_match:
                    boundary = ('--' + boundary_match.group(1).strip()).encode('utf-8')
                    fields, files = self.parse_multipart(post_data, boundary)
                    base_url = fields.get('base_url', base_url).rstrip('/')
                    api_key = fields.get('api_key', '')
                    model = fields.get('model', model)
                    prompt = fields.get('prompt', '')
                    no_slice_raw = fields.get('no_slice', 'true')
                    no_slice = (str(no_slice_raw).lower() in ['true', '1', 'yes'])
                    episode_num_raw = fields.get('episode_num', '1')
                    episode_num = int(episode_num_raw) if str(episode_num_raw).isdigit() else 1
                    prev_characters = fields.get('prev_characters', '')
                    prev_context = fields.get('prev_context', '')

                    if 'video' in files:
                        uploaded_file = files['video']
                        ext = os.path.splitext(uploaded_file['filename'])[1] or '.mp4'
                        file_path = os.path.join(SCRATCH_DIR, f'uploaded_input_{episode_num}{ext}')
                        with open(file_path, 'wb') as f:
                            f.write(uploaded_file['content'])
            else:
                try:
                    req_json = json.loads(post_data.decode('utf-8'))
                    file_path = req_json.get('file_path')
                    base64_data = req_json.get('base64_data')
                    api_key = req_json.get('api_key', '')
                    base_url = req_json.get('base_url', 'https://yunwu.ai').rstrip('/')
                    model = req_json.get('model', 'gemini-3.1-pro-preview')
                    prompt = req_json.get('prompt', '')
                    no_slice_raw = req_json.get('no_slice', 'true')
                    no_slice = (str(no_slice_raw).lower() in ['true', '1', 'yes'])
                    episode_num = int(req_json.get('episode_num', 1))
                    prev_characters = req_json.get('prev_characters', '')
                    prev_context = req_json.get('prev_context', '')

                    if base64_data:
                        file_path = os.path.join(SCRATCH_DIR, f'uploaded_input_{episode_num}.mp4')
                        with open(file_path, 'wb') as f:
                            f.write(base64.b64decode(base64_data))
                except Exception as e:
                    print(f"JSON Parse Error: {e}")

            if not file_path or not os.path.exists(file_path):
                desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
                if os.path.exists(desktop):
                    for f in os.listdir(desktop):
                        if (f.endswith('.mp4') or f.endswith('.mov')) and os.path.getsize(os.path.join(desktop, f)) > 5000000:
                            file_path = os.path.join(desktop, f)
                            break

            if not file_path or not os.path.exists(file_path):
                err_bytes = json.dumps({'error': '未找到或未成功接收视频文件！'}).encode('utf-8')
                self.send_response(400)
                self._set_cors_headers()
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(err_bytes)))
                self.end_headers()
                self.wfile.write(err_bytes)
                return

            print(f"[Python Server Engine] Processing video: {file_path}", flush=True)

            self.send_response(200)
            self._set_cors_headers()
            self.send_header('Content-Type', 'text/event-stream; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'keep-alive')
            self.end_headers()

            self.stream_fast_timeout_pipeline(file_path, base_url, api_key, model, prompt, no_slice, episode_num, prev_characters, prev_context)
            return
        else:
            self.send_error(404, "Endpoint not found")

    def stream_fast_timeout_pipeline(self, file_path, base_url, api_key, model, prompt, no_slice=True, episode_num=1, prev_characters="", prev_context=""):
        def send_evt(data_dict):
            payload = f"data: {json.dumps(data_dict, ensure_ascii=False)}\n\n"
            self.wfile.write(payload.encode('utf-8'))
            self.wfile.flush()

        clean_filename = os.path.splitext(os.path.basename(file_path))[0]
        send_evt({'type': 'progress', 'msg': f'1/4 正在利用 FFmpeg 提取第 {episode_num} 集视频的无损音轨与视频帧...'})

        audio_path = os.path.join(SCRATCH_DIR, 'temp_full_audio.mp3')
        cmd_audio = f'"{ffmpeg_exe}" -y -i "{file_path}" -vn -acodec libmp3lame -q:a 0 "{audio_path}"'
        subprocess.run(cmd_audio, capture_output=True, text=True, shell=True)

        cap = cv2.VideoCapture(file_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration_sec = total_frames / fps if fps else 60.0

        if no_slice:
            chunk_sec = duration_sec
            num_chunks = 1
            send_evt({'type': 'progress', 'msg': f'2/4 音画提取完成！全剧 {duration_sec:.1f} 秒，采用【全量直接生成】模式 (不切割切片)...'})
        else:
            chunk_sec = 25.0
            num_chunks = max(1, int(duration_sec // chunk_sec) + (1 if duration_sec % chunk_sec > 3 else 0))
            send_evt({'type': 'progress', 'msg': f'2/4 音频与画面抽帧提取完成！全剧 {duration_sec:.1f} 秒，拆分为 {num_chunks} 个 AI 分析单元...'})

        full_script = ""
        last_context_summary = "无（00:00秒开篇第一句）"
        last_scene_no = "1-1"
        global_characters = ""

        for c in range(num_chunks):
            if no_slice:
                start_t = 0.0
                end_t = duration_sec
                frame_count_target = max(1, int(duration_sec))
                send_evt({'type': 'progress', 'msg': f'3/4 全量视频发起 AI 解析 (全剧 {duration_sec:.1f}s，严格每秒 1 帧高密抽帧共 {frame_count_target} 帧)...'})
                chunk_audio_path = audio_path
            else:
                start_t = c * chunk_sec
                end_t = min((c + 1) * chunk_sec, duration_sec)
                if start_t >= duration_sec: break
                send_evt({'type': 'progress', 'msg': f'3/4 正在拆解第 {c+1}/{num_chunks} 单元 ({start_t:.1f}s ~ {end_t:.1f}s)，正在发起 API 请求...'})
                chunk_audio_path = os.path.join(SCRATCH_DIR, f'temp_audio_{c+1}.mp3')
                cmd_slice = f'"{ffmpeg_exe}" -y -ss {start_t} -to {end_t} -i "{audio_path}" -acodec copy "{chunk_audio_path}"'
                subprocess.run(cmd_slice, capture_output=True, text=True, shell=True)

            audio_b64 = ""
            if os.path.exists(chunk_audio_path):
                with open(chunk_audio_path, 'rb') as f:
                    audio_b64 = base64.b64encode(f.read()).decode('utf-8')

            if no_slice:
                frame_count_target = max(1, int(duration_sec))
                step = 1.0
                new_w = 480
                quality = 45 if frame_count_target > 80 else 55
            else:
                frame_count_target = 25
                step = max(0.4, (end_t - start_t) / frame_count_target)
                new_w = 640
                quality = 85

            chunk_frames = []
            for k in range(frame_count_target):
                sec = start_t + (k * step)
                if sec >= duration_sec: sec = max(0, duration_sec - 0.1)
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(sec * fps))
                ret, frame = cap.read()
                if ret:
                    h, w = frame.shape[:2]
                    new_h = int(h * (new_w / w))
                    resized = cv2.resize(frame, (new_w, new_h))
                    _, buf = cv2.imencode('.jpg', resized, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
                    b64_img = base64.b64encode(buf).decode('utf-8')
                    m = int(sec // 60)
                    s = int(sec % 60)
                    chunk_frames.append((f"{m:02d}:{s:02d}", f"data:image/jpeg;base64,{b64_img}"))

            char_inherit_prompt = ""
            if prev_characters:
                char_inherit_prompt = f"""
【全局角色姓名锁死继承（强制）】：
- 前几集已确定的男女主与主要人物姓名表为：【{prev_characters}】。
- 本集为第 {episode_num} 集，必须 100% 沿用【{prev_characters}】姓名！**绝对禁止中途更换男女主名字**！**绝对禁止退化使用‘女主/男主’等模糊代称**！
"""
            context_inherit_prompt = ""
            if prev_context:
                context_inherit_prompt = f"""
【前情剧本剧情与台词衔接】：
- 上一集结尾情节点为：“{prev_context}”。
- 本集为第 {episode_num} 集，请承接上述情节点继续书写。
"""

            if no_slice:
                breakdown_prompt = f"""{prompt}

========================================
【最高硬性规则·第 {episode_num} 集视频解析 (每秒 1 帧高密采样)】
短剧剧名/文件名：《{clean_filename}》。
全剧总时长：{duration_sec:.1f}秒（0.0s 至 {duration_sec:.1f}s）。
集数序号：【第 {episode_num} 集】
{char_inherit_prompt}
{context_inherit_prompt}

【核心强制规则】：
1. **集数标头声明**：正文必须从“第{episode_num}集”开始书写输出！
2. **原声台词与字幕 100% 逐字听写（核心）**：
   - 请逐字逐句听写视频中的每一句台词，绝对禁止做任何概括、合并或省略！
3. **画面动作 1:1 帧级还原**：
   - 结合每秒 1 帧的高密采样画面，精确描写每一个神态、眼神与动作！
========================================
"""
            else:
                if c == 0:
                    seamless_rule = f"1. **开篇 00:00.0 第一句台词零遗漏**：必须从开场第一字、第一句台词、从‘第{episode_num}集’标头开始输出正文！"
                    if prev_characters:
                        char_rule = f"2. **全局角色姓名锁死继承（强制）**：前几集已确定的男女主姓名表为：【{prev_characters}】。本集（第{episode_num}集）必须 100% 继承沿用【{prev_characters}】姓名，严禁变动名字！"
                    else:
                        char_rule = "2. **全局人名首发定义（核心）**：请认真辨认识别视频中出现的人物真实姓名（如‘顾明礼’、‘顾明珠’），在‘人物：...’行中列出！"
                else:
                    seamless_rule = f"""1. **无缝自然平滑衔接上文（绝对核心）**：
   - 上一单元结尾最后一句描写为：“{last_context_summary}”。
   - 本单元必须紧接上一句“{last_context_summary}”往后继续书写正文，绝对禁止发生动作与台词断层！
   - **绝对禁止重新输出‘第{episode_num}集’**！
   - **绝对禁止重新输出‘1-1、...’或‘人物：...’标头**（除非发生了真实的大换场）！直接写动作与台词！"""
                    if global_characters:
                    char_rule = f"""2. **全局人名绝对固定锁死（核心）**：
   - 全剧已锁定人物姓名表：【{global_characters}】。
   - 本单元必须 100% 沿用【{global_characters}】姓名！**绝对禁止中途换名**！
   - **绝对禁止退化使用‘女主/男主’等模糊代称**！"""
                    elif prev_characters:
                        char_rule = f"""2. **全局人名绝对固定锁死（核心）**：
   - 本集继承前集人物姓名表：【{prev_characters}】。
   - 本单元必须沿用前文确定的名字！绝对禁止中途换名！"""
                    else:
                        char_rule = """2. **全局人名绝对固定锁死（核心）**：
   - 本单元必须沿用前文确定的名字！绝对禁止中途换名，绝对禁止使用‘女主/男主’等代称！"""

                breakdown_prompt = f"""{prompt}

========================================
【最高硬性规则·第 {episode_num} 集·第 {c+1}/{num_chunks} 单元】
短剧剧名/文件名：《{clean_filename}》。
当前时间轴：{start_t:.1f}s 至 {end_t:.1f}s。
前情接续状态：上一单元停留在场次【{last_scene_no}】，结尾描述：“{last_context_summary}”。

【核心强制规则】：
{seamless_rule}
{char_rule}
3. **原声台词与字幕 100% 逐字听写（核心）**：
   - 请认真听清无损音轨里的每一句对话、看清画面底部的印制字幕！
   - 原视频说的每一句台词，必须 100% 独立成行写出，绝对禁止概括、合并或省略任何一句台词！
========================================
"""

            user_contents = [
                {'type': 'text', 'text': f'【短剧《{clean_filename}》{start_t:.1f}s ~ {end_t:.1f}s 切片画面与无损音轨】：请 1:1 零删减输出全量台词与动作：'}
            ]
            if audio_b64:
                user_contents.append({'type': 'image_url', 'image_url': {'url': f'data:audio/mp3;base64,{audio_b64}'}})

            for ts, img_url in chunk_frames:
                user_contents.append({'type': 'text', 'text': f'【时间戳 {ts}】'})
                user_contents.append({'type': 'image_url', 'image_url': {'url': img_url}})

            payload = {
                'model': model,
                'messages': [
                    {'role': 'system', 'content': breakdown_prompt},
                    {'role': 'user', 'content': user_contents}
                ],
                'temperature': 0.1,
                'max_tokens': 16384
            }

            stage1_raw_text = ""
            chat_url = f"{base_url}/v1/chat/completions" if not base_url.endswith("/v1") else f"{base_url}/chat/completions"

            # -------------------------------------------------------------
            # 📍 阶段一：1:1 客观全量音画与台词提取
            # -------------------------------------------------------------
            for attempt in range(2):
                try:
                    req = urllib.request.Request(chat_url, data=json.dumps(payload).encode('utf-8'), headers={
                        'Authorization': f'Bearer {api_key}',
                        'Content-Type': 'application/json'
                    })
                    res = urllib.request.urlopen(req, timeout=60, context=ctx)
                    data = json.loads(res.read().decode('utf-8'))

                    if 'error' in data:
                        raise Exception(data['error'].get('message', 'API Error'))

                    content = data['choices'][0]['message']['content']
                    if content and content.strip():
                        chunk_script = content.strip()
                        break
                    else:
                        raise Exception("模型返回空内容")
                except urllib.error.HTTPError as he:
                    try:
                        err_body = he.read().decode('utf-8', errors='ignore')
                        err_json = json.loads(err_body)
                        msg = err_json.get('error', {}).get('message', he.reason)
                    except Exception:
                        msg = he.reason

                    if he.code == 403:
                        err_msg = f"HTTP 403 拒绝访问: API Key 额度不足或已受限。请检查 API Key 是否有效！(报错: {msg})"
                    elif he.code == 503:
                        err_msg = f"HTTP 503 服务不可用: 当前模型 ({model}) 在中转站在线通道暂不可用。请尝试切换模型！(报错: {msg})"
                    else:
                        err_msg = f"HTTP {he.code}: {msg}"
                    send_evt({'type': 'error', 'message': err_msg})
                    cap.release()
                    return
                except Exception as ex:
                    if attempt == 1:
                        send_evt({'type': 'error', 'message': f"连接 API 失败: {str(ex)}"})
                        cap.release()
                        return
                    send_evt({'type': 'progress', 'msg': f'⚠️ 第 {c+1} 单元 API 连接重试 ({attempt+1}/2)...'})

            if chunk_script:
                lines = [l.strip() for l in chunk_script.split('\n') if l.strip()]
                if lines:
                    last_context_summary = lines[-1][:80]
                scene_matches = [l for l in lines if ('1-' in l or '场' in l)]
                if scene_matches:
                    last_scene_no = scene_matches[-1][:15]

                # 解析第一单元中定义的角色名字列表
                if c == 0:
                    import re
                    char_match = re.search(r'人物[：:]\s*(.+)', chunk_script)
                    if char_match:
                        global_characters = char_match.group(1).strip()

                cleaned_chunk = chunk_script.strip()
                if full_script and c > 0:
                    chunk_lines = cleaned_chunk.split('\n')
                    filtered_lines = []
                    for line in chunk_lines:
                        sline = line.strip()
                        if sline == "第1集" or sline.startswith("1-1") or sline.startswith("人物：") or sline.startswith("人物:"):
                            continue
                        filtered_lines.append(line)
                    cleaned_chunk = "\n".join(filtered_lines).strip()
                    full_script += "\n" + cleaned_chunk
                else:
                    full_script = cleaned_chunk
            else:
                send_evt({'type': 'error', 'message': f'第 {c+1} 单元 API 未返回内容，请检查 Base URL 与 Key'})
                cap.release()
                return

        cap.release()

        if not full_script or not full_script.strip():
            send_evt({'type': 'error', 'message': 'API 接口未返回内容。'})
            return

        desktop_dir = os.path.join(os.path.expanduser('~'), 'Desktop')
        if not os.path.exists(desktop_dir):
            desktop_dir = SCRATCH_DIR
        desktop_txt = os.path.join(desktop_dir, f"{clean_filename}_1对1零删减全量剧本.txt")
        with open(desktop_txt, 'w', encoding='utf-8') as f:
            f.write(full_script)

        send_evt({'type': 'done', 'full_script': full_script, 'desktop_file': desktop_txt})

def run():
    server_address = ('', PORT)
    httpd = HTTPServer(server_address, NativeVideoHandler)
    print(f"[Python Server Engine] Live at http://localhost:{PORT}", flush=True)
    httpd.serve_forever()

if __name__ == '__main__':
    run()
